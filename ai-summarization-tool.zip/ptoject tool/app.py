from flask import Flask, render_template, request, jsonify, send_file, send_from_directory
from werkzeug.utils import secure_filename
from transformers import BartForConditionalGeneration, BartTokenizer
from googletrans import Translator
import os
import docx
import pandas as pd
from PyPDF2 import PdfReader
import requests
from bs4 import BeautifulSoup
from complaint_classifier import ComplaintClassifier

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load BART model and tokenizer
model_name = "facebook/bart-large-cnn"
model = BartForConditionalGeneration.from_pretrained(model_name)
tokenizer = BartTokenizer.from_pretrained(model_name)
translator = Translator()

# Initialize complaint classifier
complaint_classifier = ComplaintClassifier()

def scrape_website(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        text = " ".join([p.get_text() for p in soup.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'])])
        return text
    except Exception as e:
        return f"Error scraping website: {str(e)}"

def abstractive_summary(text, length="medium"):
    if not text or not isinstance(text, str):
        return "No valid text content to summarize"
    
    try:
        length_map = {"short": 50, "medium": 150, "long": 300, "very long": 500}
        max_length = length_map.get(length, 150)

        inputs = tokenizer([text], max_length=1024, return_tensors="pt", truncation=True)
        summary_ids = model.generate(inputs['input_ids'], max_length=max_length, min_length=50, num_beams=4, length_penalty=2.0)
        summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
        return summary
    except Exception as e:
        return f"Error generating summary: {str(e)}"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    input_type = request.form.get('file_type')
    is_excel = False
    file_contents = []

    try:
        if input_type == 'text':
            content = request.form.get('text_area', '')
            if content.strip():
                file_contents.append({
                    'type': 'text',
                    'content': content
                })
        elif input_type == 'document':
            files = request.files.getlist('file_input')
            for file in files:
                if file.filename == '':
                    continue
                    
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
                file.save(file_path)
                
                try:
                    if file.filename.lower().endswith('.txt'):
                        with open(file_path, 'r', encoding='utf-8') as f:
                            file_content = f.read()
                    elif file.filename.lower().endswith('.docx'):
                        doc = docx.Document(file_path)
                        file_content = "\n".join([para.text for para in doc.paragraphs])
                    elif file.filename.lower().endswith('.pdf'):
                        reader = PdfReader(file_path)
                        file_content = "\n".join([page.extract_text() for page in reader.pages])
                    else:
                        continue
                    
                    if file_content.strip():
                        file_contents.append({
                            'filename': file.filename,
                            'content': file_content,
                            'type': 'document'
                        })
                except Exception as e:
                    file_contents.append({
                        'filename': file.filename,
                        'content': f"Error processing file: {str(e)}",
                        'type': 'error'
                    })
                finally:
                    try:
                        os.remove(file_path)
                    except:
                        pass
        elif input_type == 'excel':
            files = request.files.getlist('file_input')
            for file in files:
                if file.filename == '':
                    continue
                    
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
                file.save(file_path)
                
                try:
                    if file.filename.lower().endswith(('.xlsx', '.xls')):
                        df = pd.read_excel(file_path, engine='openpyxl')
                    elif file.filename.lower().endswith('.csv'):
                        df = pd.read_csv(file_path)
                    else:
                        continue
                    
                    is_excel = True
                    file_contents.append({
                        'filename': file.filename,
                        'content': df.to_string(),
                        'columns': df.columns.tolist(),
                        'type': 'excel'
                    })
                except Exception as e:
                    file_contents.append({
                        'filename': file.filename,
                        'content': f"Error processing file: {str(e)}",
                        'type': 'error'
                    })
                finally:
                    try:
                        os.remove(file_path)
                    except:
                        pass
        elif input_type == 'url':
            url = request.form.get('url_text', '').strip()
            if url:
                try:
                    content = scrape_website(url)
                    file_contents.append({
                        'type': 'url',
                        'content': content,
                        'url': url
                    })
                except Exception as e:
                    file_contents.append({
                        'type': 'url',
                        'content': f"Error scraping website: {str(e)}",
                        'url': url
                    })

        if not file_contents:
            return render_template('index.html', error="No valid input provided")

        if is_excel:
            return render_template('excel_summary.html', 
                               file_contents=file_contents)
        else:
            return render_template('non_excel_questions.html', 
                               input_type=input_type, 
                               file_contents=file_contents)
    
    except Exception as e:
        return render_template('index.html', error=f"Processing error: {str(e)}")

@app.route('/summarize', methods=['POST'])
def summarize():
    try:
        input_type = request.form.get('input_type')
        results = []
        
        # Get processing options (same for all files)
        summary_length = request.form.get('summary_length', 'medium')
        translate = request.form.get('translate', 'no')
        target_language = request.form.get('target_language', '')
        download_option = request.form.get('download_option', 'no')

        # Process each file's content
        i = 0
        while True:
            content_key = f'contents[{i}][content]'
            content = request.form.get(content_key)
            if not content:
                break
                
            filename = request.form.get(f'contents[{i}][filename]', '')
            
            # Generate summary for this file
            summary = abstractive_summary(content, length=summary_length)
            
            if translate == 'yes' and target_language:
                try:
                    summary = translator.translate(summary, dest=target_language).text
                except:
                    summary += "\n\n(Translation failed)"
            
            # Create download link if requested
            download_link = None
            if download_option == 'yes':
                summary_file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"summary_{i}.txt")
                with open(summary_file_path, "w", encoding="utf-8") as f:
                    f.write(summary)
                download_link = f"/download_summary/{i}"
            
            results.append({
                'filename': filename,
                'summary': summary,
                'download_link': download_link
            })
            i += 1

        if not results:
            return render_template('index.html', error="No content to summarize")

        if input_type == 'excel':
            return render_template('excel_result.html', results=results)
        else:
            return render_template('non_excel_result.html', results=results)
    
    except Exception as e:
        return render_template('index.html', error=f"Summarization error: {str(e)}")

@app.route('/download_summary/<int:file_index>')
def download_summary(file_index):
    try:
        summary_file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"summary_{file_index}.txt")
        return send_file(summary_file_path, as_attachment=True, download_name=f"summary_{file_index}.txt")
    except Exception as e:
        return str(e)

@app.route('/static/<filename>')
def static_file(filename):
    return send_from_directory('static', filename)

@app.route('/download_department/<department>')
def download_department(department):
    filename = f"{department}_complaints.csv"
    return send_from_directory('static', filename, as_attachment=True)

@app.route('/classify', methods=['POST'])
def classify():
    try:
        file_name = request.form.get('file_name')
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file_name))
        
        if file_name.lower().endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file_path, engine='openpyxl')
        elif file_name.lower().endswith('.csv'):
            df = pd.read_csv(file_path)
        else:
            return render_template('error.html', message="Unsupported file format")

        if 'complaint' not in df.columns:
            return render_template('error.html', message="Input file must contain a 'complaint' column")

        df = complaint_classifier.classify_complaints(df)
        complaint_classifier.save_department_data(df)
        complaint_classifier.generate_visualizations(df)
        churn_reasons = complaint_classifier.churn_prediction_reasons(df)
        dept_counts = df['Department'].value_counts().to_dict()
        complaints_over_time_exists = 'date_of_complaint' in df.columns

        return render_template('excel_result.html', 
                            dept_counts=dept_counts, 
                            churn_reasons=churn_reasons,
                            complaints_over_time_exists=complaints_over_time_exists,
                            message="File uploaded and processed successfully")
    except Exception as e:
        return render_template('error.html', message=f"Classification error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True)