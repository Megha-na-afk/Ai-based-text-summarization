# AI Summarization & Complaint Classification Tool

A Flask web app that summarizes text (PDF, DOCX, CSV/Excel, or scraped web pages)
using a BART transformer model, translates text, and classifies customer
complaints into departments.

## 1. Setup

Requires **Python 3.10+**.

```bash
cd "ptoject tool"

# create and activate a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# install dependencies
pip install -r requirements.txt
```

Notes:
- The first run downloads the `facebook/bart-large-cnn` summarization model
  (~1.6 GB) from Hugging Face, so you'll need an internet connection and some
  free disk space the first time.
- `torch` (PyTorch) is a large install — if you don't have a GPU, the default
  `pip install torch` from `requirements.txt` gives you the CPU build, which
  is fine for this app.

## 2. Run

```bash
python app.py
```

Then open the URL shown in the terminal (Flask apps default to
`http://127.0.0.1:5000`) in your browser.

## 3. Uploading this project to GitHub

From inside the `ptoject tool` folder:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

If you haven't created the GitHub repo yet: go to github.com → New repository →
give it a name → **do not** initialize with a README (since you already have
one) → copy the URL it gives you and use that in the `git remote add` command
above.

A `.gitignore` is already included so your virtual environment, cache files,
and runtime upload/output folders won't be pushed.
